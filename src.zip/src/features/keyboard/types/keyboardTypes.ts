export interface KeyboardState {
  /** Key pressed currently */
  keyPressed: string;
  /** Key press count */
  keyCount: number;
}
